#ESTE ES EL CODIGO DISEÑADO EN PYTHON PARA ESTO SEGUN LOS LINEAMIENTOS DE LA TAREA SE PROCEDIO A  HACER UN CALCULO DE NOTAS DE LOS ESTUDIANTES
#SE DEFINIO LA FUNCION CALCULAR NOTAS Y EN ELLA SE SOLICITA EL NOMBRE DEL ESTUDIANTE.
#EL COMANDO "INPUT" SERVIRA PARA QUE EL USUARIO PUEDA INGRESAR EL NOMBRE DEL ESTUDIENTE.
#SE APLICO EL BUCLE "WHILE TRUE PARA ASI INSERTAR NOTAD DE MANERA ILIMITADA"
#PARA PODER FINALIZAR EL BUCLE SE DEBERA "INGRSAR UN NUMERO NEGATVO" ESTO SERA POSIBLE POR MEDIO DE LA VARIABLE BREAK.
#PARA EL CALCULO DEL PROMEDIO SE UTILIZA LA VARABLE "PROMEDIO" PARA QUE SE GUARDE EL PROMEDIO DE LAS MOTAS DE LOS ESTUDIANTES, LA VARIABLE "SUM(NOTAS)" PARA PODER SUMARLAS Y "len(notas)" PARA DIVIDIRLAS.
#PARA EL TEMA DE LAS CALIFICACIONES SE UTILIZA LAS VARIABLES DEL TIPO "SPRING" SIENDO ESTAS EL "IF" Y "ELSE" QUE SE CLASIFICARA DE ACUERDO AL POMEDIO FINAL DEL ESTUDIANTE 

def calcular_promedio_notas():
    nombre_estudiante = input("Ingrese el nombre del estudiante: ")
    notas = []
    
    while True:
        try:
            nota = float(input("Ingrese una nota (número negativo para terminar): "))
            if nota < 0:
                break
            notas.append(nota)
        except ValueError:
            print("Por favor, ingrese un número válido.")

    if notas:
        promedio = sum(notas) / len(notas)
        print(f"\nEl promedio de {nombre_estudiante} es: {promedio:.2f}")

        if promedio >= 90:
            rendimiento = "Sobresaliente"
        elif promedio >= 75:
            rendimiento = "Bueno"
        elif promedio >= 50:
            rendimiento = "Regular"
        else:
            rendimiento = "Insuficiente"

        print(f"Rendimiento del estudiante: {rendimiento}")
    else:
        print("No se ingresaron notas.")

calcular_promedio_notas()
