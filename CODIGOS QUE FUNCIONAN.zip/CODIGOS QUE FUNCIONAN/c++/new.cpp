// En este ultimo caso se ejecutara el código de C++ , sus variables son las siguientes 
// nombre_estudiante:
// Tipo: string y almacena el nombre del estudiante.
// nota:
// Tipo: float  y su función será guardar cada nota ingresada por el usuario.
// suma_notas:
// Tipo: float y acumula la suma de todas las notas válidas ingresadas.
// contador:
// Tipo: int ayudara a contar el número de notas válidas ingresadas.

#include <iostream>
#include <string>

using namespace std;

int main() {
    string nombre_estudiante;
    float nota, suma_notas = 0;
    int contador = 0;

    // Solicitar el nombre del estudiante
    cout << "Ingrese el nombre del estudiante: ";
    getline(cin, nombre_estudiante);

    // Solicitar notas de manera repetitiva
    cout << "Ingrese las notas del estudiante (ingrese un valor negativo para terminar):" << endl;
    while (true) {
        cout << "Nota: ";
        cin >> nota;
        if (nota < 0) {
            break;
        }
        suma_notas += nota;
        contador++;
    }

    // Verificar si se ingresaron notas
    if (contador == 0) {
        cout << "No se ingresaron notas válidas." << endl;
    } else {
        // Calcular el promedio
        float promedio = suma_notas / contador;
        cout << "El promedio de " << nombre_estudiante << " es: " << promedio << endl;

        // Evaluar el rendimiento
        if (promedio >= 90) {
            cout << "Rendimiento: Sobresaliente" << endl;
        } else if (promedio >= 75) {
            cout << "Rendimiento: Bueno" << endl;
        } else if (promedio >= 50) {
            cout << "Rendimiento: Regular" << endl;
        } else {
            cout << "Rendimiento: Insuficiente" << endl;
        }
    }

    return 0;
}